'use client';
import { useState, useEffect } from 'react';
import { AlertTriangle, RefreshCw } from "lucide-react";
import SyncPanel from './SyncPanel';

const Infobar = () => {
  const [dbCount, setDbCount] = useState(0);
  const [showSync, setShowSync] = useState(false);
  const [syncStatus, setSyncStatus] = useState("Successfully Synced");
  const [lastSync, setLastSync] = useState(new Date());
  const [elapsed, setElapsed] = useState("just now");

  useEffect(() => {
    fetch('/api/total-records')
      .then(r => r.json())
      .then(data => setDbCount(data.totalRecords || 0));

    updateElapsed();

    const timer = setInterval(() => {
      updateElapsed();
    }, 60000);

    return () => clearInterval(timer);
  }, []);

  const updateElapsed = () => {
    const now = new Date();
    const diff = Math.floor((now - lastSync) / 1000);

    const hours = Math.floor(diff / 3600);
    const mins = Math.floor((diff % 3600) / 60);

    if (hours > 0) {
      setElapsed(`${hours}h ${mins}m ago`);
    } else if (mins > 0) {
      setElapsed(`${mins}m ago`);
    } else {
      setElapsed("just now");
    }
  };

  const syncApi = async () => {
    const res = await fetch('/api/sync');
    const data = await res.json();

    setSyncStatus(data.status || "Successfully Synced");

    const now = new Date();
    setLastSync(now);

    setElapsed("just now");
  };

  return (
    <>
      <div className="h-14 bg-white border-b flex items-center justify-between px-6">

        <div className="flex items-center gap-3 text-sm">
          <span className="font-semibold text-gray-700">Search Module</span>
          <span className="text-green-500 text-xs">●</span>

          <span className="text-gray-500">
            Database Active : 
            <span className='font-bold text-gray-700 ml-2 mr-1 '>
              {dbCount >= 1000 ? (dbCount / 1000).toFixed(2) + 'K' : dbCount}
            </span> Records
          </span>
        </div>

        <div className="flex items-center gap-3">

          <div
            onClick={() => setShowSync(true)}
            className="cursor-pointer flex items-center gap-2 px-3 py-1 rounded-full bg-green-50 border border-green-600 text-green-600 text-sm hover:bg-green-100 transition"
          >
            <AlertTriangle size={16}/>
            {syncStatus} • {elapsed}
          </div>

          <button
            onClick={syncApi}
            className="p-2 rounded-full border border-gray-200 text-gray-500 hover:bg-gray-100 hover:text-black transition"
          >
            <RefreshCw size={16} />
          </button>

        </div>

      </div>

      {showSync && <SyncPanel onClose={() => setShowSync(false)} />}
    </>
  );
};

export default Infobar;